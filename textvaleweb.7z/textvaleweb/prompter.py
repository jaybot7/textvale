###prompter.py

###it was ugly everywhere else
### we can use this for other random global stuff later too

prompter = ">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> "	